<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm text-center p-3">
            <div class="text-primary fs-1 fw-bold"><?php echo e($totalActive); ?></div>
            <div class="text-muted small">Active Bookings</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm text-center p-3">
            <div class="text-info fs-1 fw-bold"><?php echo e($reservedCount); ?></div>
            <div class="text-muted small">Reserved Stalls</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm text-center p-3">
            <div class="text-success fs-1 fw-bold"><?php echo e($nonResCount); ?></div>
            <div class="text-muted small">Non-Reserved</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm text-center p-3">
            <div class="text-danger fs-1 fw-bold"><?php echo e($pendingPass); ?></div>
            <div class="text-muted small">Pending Parking Pass</div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h6 class="mb-0">Recent Bookings</h6>
        <a href="<?php echo e(route('admin.bookings.index')); ?>" class="btn btn-sm btn-outline-primary">View All</a>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Booking ID</th><th>Name</th><th>Stall</th><th>Check-in</th><th>Check-out</th><th>Pass Status</th><th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recentBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><code><?php echo e($b->booking_id); ?></code></td>
                    <td><?php echo e($b->full_name); ?></td>
                    <td><?php echo e(ucwords(str_replace('_',' ',$b->stall_type))); ?><?php echo e($b->stall_number ? ' #'.$b->stall_number : ''); ?></td>
                    <td><?php echo e($b->check_in_date->format('M d, Y')); ?></td>
                    <td><?php echo e($b->check_out_date->format('M d, Y')); ?></td>
                    <td>
                        <?php if($b->pass_status === 'required'): ?> <span class="badge badge-pass-required">Required</span>
                        <?php elseif($b->pass_status === 'sent'): ?> <span class="badge badge-pass-sent">Sent</span>
                        <?php else: ?> <span class="badge badge-pass-not-required">N/A</span>
                        <?php endif; ?>
                    </td>
                    <td><a href="<?php echo e(route('admin.bookings.show', $b)); ?>" class="btn btn-sm btn-outline-secondary">View</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">No active bookings.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel/prp/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>